var myArr = [];
console.log(myArr.length); // -> "0"

myArr.push("dat"); // myArr == [101,"hi",true,"MG","dat"]         Push
console.log(myArr.length); // -> "5"

myArr.pop(); // myArr == [101,"hi",true,"MG"]              Pop
console.log(myArr.length); // -> "4"